# Girlfriend Day Observatory

Updated version:
- the main sky now clearly spells **HAPPY GIRLFRIENDS DAY**
- each clickable star still maps to one of the provided reasons
- all extra reason clusters are now **modeled after real constellations**
- signoff remains **from your extremely biased girlfriend**

## Publish with GitHub Pages
1. Create a new repo, for example `girlfriend-day-observatory`.
2. Upload `index.html`, `styles.css`, `script.js`, `README.md`, and `.nojekyll` to the repository root.
3. Commit.
4. Open **Settings → Pages**.
5. Choose **Deploy from a branch**.
6. Choose **main** and **/(root)**.
7. Save and wait for deployment.

No external images or API keys are required.
